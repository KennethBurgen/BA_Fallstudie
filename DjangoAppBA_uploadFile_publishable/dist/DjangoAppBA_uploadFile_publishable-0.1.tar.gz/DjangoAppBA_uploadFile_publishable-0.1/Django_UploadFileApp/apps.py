from django.apps import AppConfig


class UploadfileappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Django_UploadFileApp'
    Label = 'UploadFileApp'
